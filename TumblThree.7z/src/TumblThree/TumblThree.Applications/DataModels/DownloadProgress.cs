﻿namespace TumblThree.Applications.DataModels
{
    public class DownloadProgress
    {
        public string Progress { get; set; }
    }
}
