﻿namespace TumblThree.Applications.DataModels.TumblrCrawlerData
{
	internal interface ITumblrCrawlerData
    {

    }
}
