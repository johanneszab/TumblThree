﻿using System.Waf.Applications;

namespace TumblThree.Applications.Views
{
    public interface IAboutView : IView
    {
        void ShowDialog(object owner);
    }
}
