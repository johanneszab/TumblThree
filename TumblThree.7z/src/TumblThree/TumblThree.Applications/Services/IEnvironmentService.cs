﻿namespace TumblThree.Applications.Services
{
    public interface IEnvironmentService
    {
        string AppSettingsPath { get; }
    }
}
