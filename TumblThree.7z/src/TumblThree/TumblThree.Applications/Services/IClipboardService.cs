﻿namespace TumblThree.Applications.Services
{
    public interface IClipboardService
    {
        void SetText(string text);
    }
}
