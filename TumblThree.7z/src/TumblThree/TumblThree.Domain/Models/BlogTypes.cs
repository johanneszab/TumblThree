﻿namespace TumblThree.Domain.Models
{
    public enum BlogTypes
    {
        tumblr,
        tmblrpriv,
        instagram,
        twitter,
        tlb,
        tumblrsearch,
        tumblrtagsearch,
        all
    }
}
