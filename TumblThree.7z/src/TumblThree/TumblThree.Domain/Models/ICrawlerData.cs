﻿using System;

namespace TumblThree.Domain.Models
{
    public interface ICrawlerData
    {
        Type BlogType { get; }
    }
}
