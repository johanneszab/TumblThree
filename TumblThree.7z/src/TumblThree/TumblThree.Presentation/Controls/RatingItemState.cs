﻿namespace TumblThree.Presentation.Controls
{
    public enum RatingItemState
    {
        Empty,
        Partial,
        Filled
    }
}
