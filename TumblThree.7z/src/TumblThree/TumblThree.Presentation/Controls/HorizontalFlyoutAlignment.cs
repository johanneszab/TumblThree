﻿namespace TumblThree.Presentation.Controls
{
    public enum HorizontalFlyoutAlignment
    {
        Left,
        Center,
        Right
    }
}
