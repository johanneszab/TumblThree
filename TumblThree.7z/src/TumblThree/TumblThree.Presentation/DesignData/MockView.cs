﻿using System.Waf.Applications;

namespace TumblThree.Presentation.DesignData
{
    public class MockView : IView
    {
        public object DataContext { get; set; }
    }
}
