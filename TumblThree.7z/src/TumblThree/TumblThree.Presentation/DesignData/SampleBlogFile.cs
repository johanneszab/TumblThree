﻿using TumblThree.Domain.Models;

namespace TumblThree.Presentation.DesignData
{
    public class SampleBlogFile : Blog
    {
        public SampleBlogFile(string url)
        {
        }
    }
}
