﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace TumblThree.Presentation.Converters
{
    public class BlogQueueProgressConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            //if (values.First() == DependencyProperty.UnsetValue) { return DependencyProperty.UnsetValue; }

            //var downloadedImages = values[0];
            //var totalImages = values[1];

            //return string.Format(CultureInfo.CurrentCulture, Resources.DownloadedImagesOf, downloadedImages, totalImages);

            return values[0];
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
