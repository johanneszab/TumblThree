﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("TumblThree")]
[assembly: AssemblyCopyright("Copyright (C) 2016-2018 Johannes Meyer zum Alten Borgloh")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: CLSCompliant(false)] // The WinRT API is not CLS-compliant (e.g. usage of uint)

[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.MainAssembly)]
[assembly: AssemblyVersion("1.0.8.39")]
[assembly: AssemblyFileVersion("1.0.8.39")]
